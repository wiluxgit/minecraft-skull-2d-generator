Source: https://github.com/OscarDahlqvist/minecraft-skull-2d-generator

How to use
1. Have python 3 installed
2. Know how to install python dependencies
3. Open CMD in same directory as skullify.py and type:
python skullify.py <relative path to file you want to skullify>

example:
python skullify.py example/button.png